const seq = require('./src/model/index');
seq.sequelize.query('DROP TABLE IF EXISTS login_histories')
  .then(() => { console.log('Table dropped'); process.exit(0); })
  .catch(e => { console.error(e.message); process.exit(1); });
