const { v4: uuidv4 } = require('uuid');
const db = require('../../model/index');

const sequelize = db.sequelize;
const PenyakitAyam = db.PenyakitAyam;
const Sakit = db.Sakit;
const LaporanGejala = db.LaporanGejala;
const Laporan = db.Laporan;
const PenyakitGejala = db.PenyakitGejala;
const Gejala = db.Gejala;
const CfWeightLog = db.CfWeightLog;
const PenangananPenyakitAyam = db.PenangananPenyakitAyam;
const cfHelper = require("../../utils/cfHelper");

const getAllPenyakit = async (req, res) => {

    try {
        const penyakit = await PenyakitAyam.findAll();

        return res.status(200).json({
            message: 'Successfully retrieved penyakit data',
            data: penyakit,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const getPenyakitWithGejala = async (req, res) => {
    try {
        const penyakit = await PenyakitAyam.findAll({
            include: [{
                model: PenyakitGejala,
                as: 'penyakitGejala',
                include: [{ model: Gejala, as: 'gejala' }],
            }],
        });

        return res.status(200).json({
            message: 'Successfully retrieved penyakit with gejala data',
            data: penyakit,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const getPenyakitWithPenanganan = async (req, res) => {
    try {
        const PenangananPenyakitAyam = db.PenangananPenyakitAyam;
        const penyakit = await PenyakitAyam.findAll({
            include: [{
                model: PenangananPenyakitAyam,
                as: 'penanganan',
            }],
        });

        return res.status(200).json({
            message: 'Successfully retrieved penyakit with penanganan data',
            data: penyakit,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const diagnosaPenyakitAyam = async (req, res) => {
    try {
        const { gejala = [] } = req.body

        if (!Array.isArray(gejala) || gejala.length === 0) {
            return res.status(400).json({
                message: "Gejala tidak boleh kosong"
            });
        }

        const daftarGejala = await Gejala.findAll({
            where: {
                id: gejala.map((g) => g.id)
            },
        });

        const namaGejala = daftarGejala.map((g) => g.nama_gejala)

        const hasil = await cfHelper.diagnosePenyakit(gejala)

        const penanganan = hasil?.id
            ? await PenangananPenyakitAyam.findAll({
                where: { penyakit_id: hasil.id },
            })
            : [];

        return res.status(200).json({
            message: 'Diagnosis berhasil',
            gejala_dipilih: gejala.length,
            data: {
                ...hasil,
                gejala_terdeteksi: namaGejala,
                penanganan,
            }
        })

    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
}

const createPenyakit = async (req, res) => {
    const { nama_penyakit, gejala_ids = [], metode = 'idf' } = req.body;

    if (!nama_penyakit || !nama_penyakit.trim()) {
        return res.status(400).json({ message: 'nama_penyakit wajib diisi' });
    }
    if (!Array.isArray(gejala_ids) || gejala_ids.length === 0) {
        return res.status(400).json({ message: 'gejala_ids wajib diisi minimal 1 gejala' });
    }

    const transaction = await sequelize.transaction();
    try {
        // Validasi gejala_ids ada di DB
        const gejalaValid = await Gejala.findAll({
            where: { id: gejala_ids },
            transaction,
        });
        if (gejalaValid.length !== gejala_ids.length) {
            await transaction.rollback();
            return res.status(400).json({ message: 'Satu atau lebih gejala_id tidak valid' });
        }

        const penyakit = await PenyakitAyam.create({
            id: uuidv4(),
            nama_penyakit: nama_penyakit.trim(),
        }, { transaction });


        const relasiData = gejala_ids.map(gejalaId => ({
            id: uuidv4(),
            penyakit_id: penyakit.id,
            gejala_id: gejalaId,
            cf_weight: 0,
            // penanganan_id: penanganan.id,
            metode,
        }));

        await PenyakitGejala.bulkCreate(relasiData, { transaction });

        // 3. Recalculate seluruh bobot CF karena N bertambah
        await _recalculateCF(transaction, metode);

        await transaction.commit();

        // Ambil data lengkap untuk response
        const result = await PenyakitAyam.findByPk(penyakit.id, {
            include: [{
                model: PenyakitGejala,
                as: 'penyakitGejala',
                include: [{ model: Gejala, as: 'gejala' }],
            }],
        });

        return res.status(201).json({
            message: 'Penyakit berhasil ditambahkan dan bobot CF otomatis dihitung ulang',
            data: result,
        });
    } catch (error) {
        await transaction.rollback();
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const createLaporanPenyakit = async (req, res) => {
    let transaction;
    try {
        transaction = await sequelize.transaction();
        const { sakit } = req.body;

        const data = await Laporan.create(
            {
                ...req.body,
                UnitBudidayaId: req.body.unitBudidayaId,
                ObjekBudidayaId: req.body.objekBudidayaId,
                UserId: req.user.id,
            },
            { transaction }
        );
        const laporanGejala = await LaporanGejala.bulkCreate(
            (sakit.gejala || []).map((g) => ({
                penyakit_ayam_id: sakit.penyakitAyamId,
                gejala_id: g.id || g.gejala_id,
            })),
            { transaction }
        );
        const dataPenyakit = await Sakit.create(
            {
                LaporanId: data.id,
                diagnosisPenyakit: sakit.penyakitAyamId,
                status: req.body.status,
            },
            { transaction }
        );

        await transaction.commit();
        res.locals.createdData = { data, laporanGejala, dataPenyakit };
        return res.status(201).json({
            message: 'Laporan penyakit berhasil dibuat',
            data: { data, laporanGejala, dataPenyakit },
        });
    } catch (error) {
        if (transaction) await transaction.rollback();
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const updateStatusLaporanPenyakit = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        let dataPenyakit = await Sakit.findOne({
            where: { id },
        });

        let data;
        if (dataPenyakit) {
            data = await Laporan.findOne({
                where: {
                    id: dataPenyakit.LaporanId,
                    isDeleted: false,
                    tipe: "sakit",
                },
            });
        } else {
            data = await Laporan.findOne({
                where: {
                    id,
                    isDeleted: false,
                    tipe: "sakit",
                },
            });

            if (data) {
                dataPenyakit = await Sakit.findOne({
                    where: {
                        LaporanId: id,
                    },
                });
            }
        }

        if (!data) {
            return res.status(404).json({ message: 'Laporan penyakit tidak ditemukan' });
        }
        if (!dataPenyakit) {
            return res.status(404).json({ message: 'Data penyakit tidak ditemukan' });
        }

        await dataPenyakit.update({
            status: status,
        });

        return res.status(200).json({
            message: 'Laporan penyakit berhasil diupdate',
            data: { data, dataPenyakit },
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const getRiwayatPenyakitAyam = async (req, res) => {
    const { id } = req.params;
    try {

        const laporan = await Laporan.findAll({
            where: {
                isDeleted: false,
                tipe: "sakit",
                unitBudidayaId: id
            },
            include: [
                {
                    model: Sakit,
                    include: [
                        {
                            model: PenyakitAyam,
                            paranoid: false,
                            attributes: ['nama_penyakit']
                        }
                    ]
                },
            ],
            order: [['createdAt', 'DESC']]
        });
        
        const formattedData = laporan.map(item => {
            const data = item.toJSON();
            if (data.Sakit) {
                data.Sakit.diagnosisPenyakit = data.Sakit.PenyakitAyam 
                    ? data.Sakit.PenyakitAyam.nama_penyakit 
                    : "Unknown";
                delete data.Sakit.PenyakitAyam;
            }
            return data;
        });

        return res.status(200).json({
            message: 'Successfully retrieved penyakit data',
            data: formattedData,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const getRiwayatPenyakitAyamById = async (req, res) => {
    try {
        const { id } = req.params;
        const laporan = await Laporan.findOne({
            where: {
                id,
                isDeleted: false,
                tipe: "sakit",
            },
            include: [
                {
                    model: Sakit,
                },
            ],
        });

        const namaPenyakit = await PenyakitAyam.findOne({
            where: {
                id: laporan.Sakit.diagnosisPenyakit,
            },
            paranoid: false,
        });

        const laporanGejalaList = await LaporanGejala.findAll({
            where: {
                penyakit_ayam_id: laporan.Sakit.diagnosisPenyakit,
            }
        });

        const listGejala = await Gejala.findAll({
            where: {
                id: laporanGejalaList.map((g) => g.gejala_id),
            },
        });

        // Cari penyakit aktif dengan nama yang sama untuk mendapatkan penanganan terbarunya
        let targetPenyakitId = laporan.Sakit.diagnosisPenyakit;
        if (namaPenyakit) {
            const activePenyakit = await PenyakitAyam.findOne({
                where: { nama_penyakit: namaPenyakit.nama_penyakit },
            });
            if (activePenyakit) {
                targetPenyakitId = activePenyakit.id;
            }
        }

        const penanganan = await PenangananPenyakitAyam.findAll({
            where: {
                penyakit_id: targetPenyakitId,
            },
        });

        return res.status(200).json({
            message: 'Successfully retrieved penyakit data',
            data: { laporan, namaPenyakit, listGejala, penanganan },
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const createPenangananPenyakitAyam = async (req, res) => {
    let transaction;
    try {
        transaction = await sequelize.transaction();
        const { id_penyakit, catatan, gambar } = req.body;

        // Validasi penyakit ada
        const existingPenyakit = await PenyakitAyam.findOne({
            where: { id: id_penyakit },
            transaction,
        });
        if (!existingPenyakit) {
            await transaction.rollback();
            return res.status(404).json({ message: 'Penyakit tidak ditemukan' });
        }

        // Simpan penanganan dengan penyakit_id langsung
        const data = await PenangananPenyakitAyam.create(
            {
                id: uuidv4(),
                penyakit_id: id_penyakit,
                penanganan: catatan,
                gambar: gambar,
            },
            { transaction }
        );

        await transaction.commit();
        res.locals.createdData = { data };
        return res.status(201).json({
            message: 'Penanganan penyakit berhasil dibuat',
            data: { data },
        });
    } catch (error) {
        if (transaction) await transaction.rollback();
        return res.status(500).json({ message: error.message, detail: error });
    }
};



const getPenangananPenyakitAyamById = async (req, res) => {
    try {
        const { id } = req.params;
        const data = await PenangananPenyakitAyam.findOne({
            where: {
                id,
            },
        });

        return res.status(200).json({
            message: 'Successfully retrieved penyakit data',
            data,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};



const updatePenangananPenyakitAyam = async (req, res) => {
    try {
        const { id } = req.params;
        const { catatan, gambar } = req.body;

        const existingPenanganan = await PenangananPenyakitAyam.findOne({
            where: { id },
        });

        if (!existingPenanganan) {
            return res.status(404).json({ message: 'Penanganan tidak ditemukan' });
        }

        await existingPenanganan.update({
            ...(catatan !== undefined && { penanganan: catatan }),
            ...(gambar !== undefined && { gambar }),
        });

        return res.status(200).json({
            message: 'Penanganan penyakit berhasil diupdate',
            data: existingPenanganan,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};



const deletePenangananPenyakitAyam = async (req, res) => {
    try {
        const { id } = req.params;

        const existingPenanganan = await PenangananPenyakitAyam.findOne({
            where: { id },
        });

        if (!existingPenanganan) {
            return res.status(404).json({ message: 'Penanganan tidak ditemukan' });
        }

        // Soft delete: mengisi deletedAt
        await existingPenanganan.destroy();

        return res.status(200).json({
            message: 'Penanganan penyakit berhasil dihapus',
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const updatePenyakit = async (req, res) => {
    const { id } = req.params;
    const { nama_penyakit, gejala_ids, metode = 'idf' } = req.body;

    const transaction = await sequelize.transaction();
    try {
        const existingPenyakit = await PenyakitAyam.findOne({
            where: { id },
            transaction,
        });

        if (!existingPenyakit) {
            await transaction.rollback();
            return res.status(404).json({ message: 'Penyakit tidak ditemukan' });
        }

        if (nama_penyakit !== undefined) {
            await existingPenyakit.update(
                { nama_penyakit: nama_penyakit.trim() },
                { transaction }
            );
        }

        if (Array.isArray(gejala_ids) && gejala_ids.length > 0) {
            // Validasi gejala_ids
            const gejalaValid = await Gejala.findAll({
                where: { id: gejala_ids },
                transaction,
            });
            if (gejalaValid.length !== gejala_ids.length) {
                await transaction.rollback();
                return res.status(400).json({ message: 'Satu atau lebih gejala_id tidak valid' });
            }

            // Ambil id relasi lama untuk hapus CfWeightLog terkait
            const relasiLama = await PenyakitGejala.findAll({
                where: { penyakit_id: id },
                transaction,
            });
            const relasiLamaIds = relasiLama.map(r => r.id);

            // Hapus CfWeightLog yang mereferensikan relasi lama (FK constraint)
            if (relasiLamaIds.length > 0) {
                await CfWeightLog.destroy({
                    where: { penyakit_gejala_id: relasiLamaIds },
                    transaction,
                });
            }

            // Hapus relasi lama
            await PenyakitGejala.destroy({
                where: { penyakit_id: id },
                transaction,
            });

            // Buat relasi baru
            const relasiData = gejala_ids.map(gejalaId => ({
                id: uuidv4(),
                penyakit_id: id,
                gejala_id: gejalaId,
                cf_weight: 0,
                metode,
            }));
            await PenyakitGejala.bulkCreate(relasiData, { transaction });

            // Recalculate CF karena relasi berubah
            await _recalculateCF(transaction, metode);
        }

        await transaction.commit();

        const result = await PenyakitAyam.findByPk(id, {
            include: [{
                model: PenyakitGejala,
                as: 'penyakitGejala',
                include: [{ model: Gejala, as: 'gejala' }],
            }],
        });

        return res.status(200).json({
            message: 'Penyakit berhasil diupdate dan bobot CF otomatis dihitung ulang',
            data: result,
        });
    } catch (error) {
        await transaction.rollback();
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const deletePenyakit = async (req, res) => {
    const { id } = req.params;
    const transaction = await sequelize.transaction();

    try {
        const existingPenyakit = await PenyakitAyam.findOne({
            where: { id },
            transaction,
        });

        if (!existingPenyakit) {
            await transaction.rollback();
            return res.status(404).json({ message: 'Penyakit tidak ditemukan' });
        }

        // Soft delete: mengisi deletedAt
        await existingPenyakit.destroy({ transaction });

        // Recalculate CF karena N berkurang
        await _recalculateCF(transaction, 'idf');

        await transaction.commit();

        return res.status(200).json({
            message: 'Penyakit berhasil dihapus dan bobot CF otomatis dihitung ulang',
        });
    } catch (error) {
        await transaction.rollback();
        return res.status(500).json({ message: error.message, detail: error });
    }
};



const getStatistikPenyakitAyam = async (req, res) => {
    try {
        const { unitBudidayaId, year } = req.query;
        const currentYear = year ? parseInt(year) : new Date().getFullYear();
        
        const whereClause = {
            isDeleted: false,
            tipe: "sakit"
        };
        
        if (unitBudidayaId) {
            whereClause.UnitBudidayaId = unitBudidayaId;
        }

        const laporan = await Laporan.findAll({
            where: whereClause,
            include: [
                {
                    model: Sakit,
                    include: [
                        {
                            model: PenyakitAyam,
                            paranoid: false,
                            attributes: ['nama_penyakit']
                        }
                    ]
                },
            ]
        });

        const stats = {};

        laporan.forEach(item => {
            const date = new Date(item.createdAt);
            if (date.getFullYear() === currentYear) {
                const month = date.getMonth(); // 0 to 11
                const penyakit = item.Sakit?.PenyakitAyam?.nama_penyakit || "Unknown";
                
                if (!stats[penyakit]) {
                    stats[penyakit] = Array(12).fill(0);
                }
                
                stats[penyakit][month] += 1;
            }
        });

        // Format untuk frontend chart
        const chartData = Object.keys(stats).map(penyakit => ({
            name: penyakit,
            data: stats[penyakit] // Array 12 elemen (Jan-Des)
        }));

        return res.status(200).json({
            message: 'Berhasil mengambil statistik penyakit ayam',
            year: currentYear,
            data: chartData,
        });
    } catch (error) {
        return res.status(500).json({ message: error.message, detail: error });
    }
};

const _recalculateCF = async (transaction, metode = 'idf') => {
    const allRelasi = await PenyakitGejala.findAll({ transaction });

    const uniquePenyakitIds = [...new Set(allRelasi.map(r => r.penyakit_id))];
    const N = uniquePenyakitIds.length;

    const dfMap = {};
    for (const r of allRelasi) {
        dfMap[r.gejala_id] = (dfMap[r.gejala_id] || 0) + 1;
    }

    for (const r of allRelasi) {
        const df = dfMap[r.gejala_id] || 1;
        const cfBaru = cfHelper.computeCF(df, N, metode);

        await CfWeightLog.create({
            id: uuidv4(),
            penyakit_gejala_id: r.id,
            cf_weight_lama: r.cf_weight,
            cf_weight_baru: cfBaru,
            total_disease_lama: r.total_disease,
            triggered_by: `recalculate_${metode}`,
        }, { transaction });

        await r.update({
            cf_weight: cfBaru,
            disease_frequency: df,
            total_disease: N,
            metode,
            cf_updated_at: new Date(),
        }, { transaction });
    }
};



module.exports = {
    getAllPenyakit,
    getPenyakitWithGejala,
    getPenyakitWithPenanganan,
    getRiwayatPenyakitAyam,
    getRiwayatPenyakitAyamById,
    getPenangananPenyakitAyamById,
    diagnosaPenyakitAyam,
    createLaporanPenyakit,
    createPenyakit,
    updatePenyakit,
    deletePenyakit,
    createPenangananPenyakitAyam,
    updatePenangananPenyakitAyam,
    deletePenangananPenyakitAyam,
    updateStatusLaporanPenyakit,
    getStatistikPenyakitAyam,
    _recalculateCF,
};