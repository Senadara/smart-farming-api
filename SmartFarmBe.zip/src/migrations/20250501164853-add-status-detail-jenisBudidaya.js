"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    /**
     * Add altering commands here.
     *
     * Example:
     * await queryInterface.createTable('users', { id: Sequelize.INTEGER });
     */
    await queryInterface.addColumn("jenisBudidaya", "status", {
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: true,
      after: "latin",
    });
    await queryInterface.addColumn("jenisBudidaya", "detail", {
      type: Sequelize.TEXT,
      allowNull: true,
      after: "status",
    });
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
    await queryInterface.removeColumn("jenisBudidaya", "status");
    await queryInterface.removeColumn("jenisBudidaya", "detail");
  },
};
